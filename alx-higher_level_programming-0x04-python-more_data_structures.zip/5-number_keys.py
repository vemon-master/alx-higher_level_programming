#!/usr/bin/python3
# -----------------------------------------------------------
# Python program that:
# demonstrates how to return the number of keys in a dictionary
#
# (C) 2022 Igbinijesu Samuel, Lagos, Nigeria
# email igbinijesusamuel@gmail.com
# -----------------------------------------------------------


def number_keys(a_dictionary):
    return len(a_dictionary.keys())
